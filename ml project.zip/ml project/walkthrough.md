# Walkthrough: Car Price Prediction App & Interactive Studio

We have built, trained, evaluated, and deployed the **AutoPrice AI Studio** car price prediction system, featuring an end-to-end machine learning pipeline and a modern, glassmorphic Streamlit web application.

---

## 1. Machine Learning Pipeline & Training Results

We ingested and cleaned the Kaggle CarDekho dataset (`8,128` raw entries -> `6,898` clean samples).
- **Data Preprocessing**: Extracted numeric values from units (`mileage`, `engine`, `max_power`), extracted `brand` and `model` from car names, imputed missing values with median/mode, standard scaled numerical features, and one-hot encoded categorical variables.
- **Model Evaluation**: Evaluated **Linear Regression**, **Random Forest**, and **XGBoost** on a holdout test split (20%) using **MAE**, **RMSE**, and **R² Score**.

### Model Benchmark Results

| Model | MAE (Mean Absolute Error) | RMSE (Root Mean Squared Error) | R² Score | Status |
| :--- | :--- | :--- | :--- | :--- |
| **Linear Regression** | ₹ 115,290.84 | ₹ 291,434.84 | 0.7614 | Baseline |
| **XGBoost Regressor** | ₹ 78,660.09 | ₹ 222,496.70 | 0.8609 | Strong Contender |
| **Random Forest Regressor** | **₹ 78,202.28** | **₹ 214,769.81** | **0.8704** | 🏆 **Best Model (Saved)** |

The best model pipeline (Random Forest with full preprocessor) was persisted to [`best_model.joblib`](file:///d:/ml%20project/best_model.joblib). Model metrics and UI metadata were exported to [`model_metrics.json`](file:///d:/ml%20project/model_metrics.json) and [`model_metadata.json`](file:///d:/ml%20project/model_metadata.json).

---

## 2. Interactive Streamlit Web Application Features

The application runs locally on **`http://localhost:8501`** and provides a suite of interactive features:

1. **Sidebar Customization**:
   - Dynamic **Brand** and **Model** dropdowns (the model list updates reactively based on the selected brand).
   - Sliders and numeric inputs for **Year of Manufacture**, **Kilometers Driven**, **Fuel Type**, **Transmission**, **Mileage (kmpl)**, **Engine (CC)**, and **Max Power (bhp)**.
2. **Tab 1: Single Prediction & Spec Breakdown**:
   - Real-time valuation card with highlighted gradient aesthetics, fair market price range, spec summary badges, and depreciation estimates.
3. **Tab 2: Side-by-Side Car Comparison**:
   - Compare two vehicles with distinct specs side-by-side.
   - Computes valuation differential, percentage disparity, and an interactive Plotly comparison bar chart.
4. **Tab 3: Model Analytics & Visualizations**:
   - Full model comparison table with automatic highlighters for MAE, RMSE, and R².
   - Interactive horizontal bar chart of **Feature Importances** (identifying Engine Size, Max Power, Year, and KM Driven as primary price drivers).
   - Exploratory charts: **Price vs. Mileage**, **Price vs. Year**, and **Selling Price Distribution**.
5. **Tab 4: Batch CSV Prediction**:
   - Provides a downloadable sample CSV template.
   - Supports drag-and-drop CSV upload for bulk predictions, displaying augmented results and a 1-click download button.

---

## 3. Visual Demonstration & Screenshots

````carousel
![Single Prediction View](C:\Users\SAI RAHUL RAJ\.gemini\antigravity-ide\brain\6e7f3a54-c1c9-4e6e-9714-4820ef702c3a\final_single_prediction_view_1789032870283.png)
<!-- slide -->
![Side-by-Side Car Comparison](C:\Users\SAI RAHUL RAJ\.gemini\antigravity-ide\brain\6e7f3a54-c1c9-4e6e-9714-4820ef702c3a\compare_bar_chart_1789032551629.png)
<!-- slide -->
![Model Evaluation & Analytics](C:\Users\SAI RAHUL RAJ\.gemini\antigravity-ide\brain\6e7f3a54-c1c9-4e6e-9714-4820ef702c3a\model_analytics_eval_1789032686433.png)
<!-- slide -->
![Batch Prediction Tool](C:\Users\SAI RAHUL RAJ\.gemini\antigravity-ide\brain\6e7f3a54-c1c9-4e6e-9714-4820ef702c3a\batch_prediction_view_1789032820390.png)
````

### Browser Session Recording
A recording of the live browser validation is available:
![Browser Verification Recording](C:\Users\SAI RAHUL RAJ\.gemini\antigravity-ide\brain\6e7f3a54-c1c9-4e6e-9714-4820ef702c3a\car_price_app_demo_1789032217278.webp)

---

## 4. How to Run

To run the Streamlit application at any time:

```powershell
# Navigate to the workspace directory
cd "d:\ml project"

# Run Streamlit
& "C:\Users\SAI RAHUL RAJ\anaconda3\python.exe" -m streamlit run app.py
```
Open **`http://localhost:8501`** in any browser.
