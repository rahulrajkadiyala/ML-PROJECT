import os
import json
import joblib
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

# ---------------------------------------------------------
# Page Configuration & Rich Aesthetics
# ---------------------------------------------------------
st.set_page_config(
    page_title="AutoPrice AI | Car Valuation Studio",
    page_icon="🚘",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for rich aesthetics, vibrant colors, glassmorphism, and micro-interactions
st.markdown("""
<style>
    /* Google Fonts import */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap');

    html, body, [class*="css"], [class*="st-"] {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }

    /* Full-canvas background with luminous atmospheric gradient orbs */
    .stApp, [data-testid="stAppViewContainer"] {
        background: 
            radial-gradient(circle at 10% 15%, rgba(99, 102, 241, 0.22) 0%, transparent 40%),
            radial-gradient(circle at 90% 12%, rgba(6, 182, 212, 0.20) 0%, transparent 42%),
            radial-gradient(circle at 50% 85%, rgba(217, 70, 239, 0.15) 0%, transparent 48%),
            radial-gradient(circle at 20% 70%, rgba(16, 185, 129, 0.12) 0%, transparent 35%),
            #070a13 !important;
        color: #f8fafc !important;
    }

    [data-testid="stHeader"] {
        background: transparent !important;
    }

    /* Luminous Sidebar */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0b1120 0%, #070a14 100%) !important;
        border-right: 1px solid rgba(99, 102, 241, 0.3) !important;
        box-shadow: 8px 0 32px rgba(0, 0, 0, 0.6) !important;
    }

    /* Section divider in sidebar */
    .sidebar-section-header {
        font-size: 0.85rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        color: #38bdf8;
        margin: 18px 0 8px 0;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* Glassmorphic cards with vibrant border highlights */
    .glass-card {
        background: rgba(15, 23, 42, 0.72) !important;
        border: 1px solid rgba(99, 102, 241, 0.28) !important;
        border-radius: 18px !important;
        padding: 24px !important;
        box-shadow: 0 12px 35px -5px rgba(0, 0, 0, 0.5), 0 0 24px -5px rgba(99, 102, 241, 0.18) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        margin-bottom: 20px;
    }
    .glass-card:hover {
        border-color: rgba(6, 182, 212, 0.5) !important;
        box-shadow: 0 16px 45px -5px rgba(0, 0, 0, 0.6), 0 0 30px rgba(6, 182, 212, 0.25) !important;
        transform: translateY(-2px);
    }

    /* Hero Prediction Card */
    .prediction-hero-card {
        background: linear-gradient(135deg, rgba(30, 27, 75, 0.85) 0%, rgba(15, 23, 42, 0.90) 50%, rgba(17, 24, 39, 0.92) 100%) !important;
        border: 1.5px solid rgba(139, 92, 246, 0.55) !important;
        border-radius: 24px !important;
        padding: 34px 28px !important;
        text-align: center !important;
        box-shadow: 0 20px 60px -10px rgba(99, 102, 241, 0.4), 0 0 40px -5px rgba(6, 182, 212, 0.25), inset 0 1px 1px rgba(255, 255, 255, 0.15) !important;
        backdrop-filter: blur(20px) !important;
        position: relative !important;
        overflow: hidden !important;
        margin: 20px 0 28px 0 !important;
    }

    .prediction-hero-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; height: 3px;
        background: linear-gradient(90deg, #06b6d4, #6366f1, #d946ef, #06b6d4);
        background-size: 200% 100%;
        animation: gradientShift 4s linear infinite;
    }

    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    /* Price Tag typography */
    .price-tag-vivid {
        font-size: 3.6rem !important;
        font-weight: 900 !important;
        background: linear-gradient(135deg, #22d3ee 0%, #818cf8 40%, #c084fc 70%, #f472b6 100%) !important;
        -webkit-background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        filter: drop-shadow(0 4px 18px rgba(129, 140, 248, 0.45));
        margin: 10px 0 !important;
        letter-spacing: -1.5px !important;
        line-height: 1.1 !important;
    }

    /* Price Range Pill */
    .price-range-container {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 16px;
        flex-wrap: wrap;
        margin-top: 14px;
    }

    .range-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 18px;
        border-radius: 30px;
        font-size: 0.95rem;
        font-weight: 600;
        backdrop-filter: blur(10px);
    }
    .range-chip.low {
        background: rgba(6, 182, 212, 0.15);
        color: #22d3ee;
        border: 1px solid rgba(6, 182, 212, 0.4);
    }
    .range-chip.fair {
        background: rgba(99, 102, 241, 0.2);
        color: #a5b4fc;
        border: 1px solid rgba(99, 102, 241, 0.45);
    }
    .range-chip.high {
        background: rgba(217, 70, 239, 0.15);
        color: #f472b6;
        border: 1px solid rgba(217, 70, 239, 0.4);
    }

    /* Visual Valuation Meter */
    .valuation-meter-bar {
        height: 10px;
        border-radius: 10px;
        background: linear-gradient(90deg, #06b6d4 0%, #10b981 35%, #818cf8 65%, #f43f5e 100%);
        margin: 18px auto 8px auto;
        max-width: 520px;
        box-shadow: 0 0 15px rgba(99, 102, 241, 0.5);
    }
    .meter-labels {
        display: flex;
        justify-content: space-between;
        max-width: 520px;
        margin: auto;
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        color: #94a3b8;
    }

    /* Model Status Badge */
    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 7px 18px;
        border-radius: 30px;
        font-size: 0.85rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.25) 0%, rgba(217, 70, 239, 0.25) 100%);
        color: #e0e7ff;
        border: 1px solid rgba(139, 92, 246, 0.5);
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
        margin-bottom: 12px;
    }
    .pulse-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #34d399;
        box-shadow: 0 0 10px #34d399;
        display: inline-block;
        animation: pulseAnimation 2s infinite;
    }
    @keyframes pulseAnimation {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.4; transform: scale(0.85); }
    }

    /* Top KPI Pills */
    .kpi-row {
        display: flex;
        gap: 14px;
        justify-content: center;
        flex-wrap: wrap;
        margin: 16px 0 24px 0;
    }
    .kpi-item {
        background: rgba(15, 23, 42, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
        padding: 8px 18px;
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.25);
    }
    .kpi-icon {
        font-size: 1.25rem;
    }
    .kpi-title {
        font-size: 0.72rem;
        color: #94a3b8;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.6px;
    }
    .kpi-val {
        font-size: 0.95rem;
        color: #f8fafc;
        font-weight: 800;
    }

    /* Specification Pill Cards */
    .spec-card {
        background: rgba(15, 23, 42, 0.75);
        border-radius: 16px;
        padding: 16px 14px;
        text-align: center;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        box-shadow: 0 4px 18px rgba(0, 0, 0, 0.3);
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    .spec-card:hover {
        transform: translateY(-3px);
    }

    .spec-card.cyan {
        border: 1.5px solid rgba(6, 182, 212, 0.4);
        box-shadow: 0 6px 20px -5px rgba(6, 182, 212, 0.25);
    }
    .spec-card.cyan .spec-icon { background: rgba(6, 182, 212, 0.15); color: #22d3ee; }

    .spec-card.amber {
        border: 1.5px solid rgba(245, 158, 11, 0.4);
        box-shadow: 0 6px 20px -5px rgba(245, 158, 11, 0.25);
    }
    .spec-card.amber .spec-icon { background: rgba(245, 158, 11, 0.15); color: #fbbf24; }

    .spec-card.magenta {
        border: 1.5px solid rgba(217, 70, 239, 0.4);
        box-shadow: 0 6px 20px -5px rgba(217, 70, 239, 0.25);
    }
    .spec-card.magenta .spec-icon { background: rgba(217, 70, 239, 0.15); color: #f472b6; }

    .spec-card.emerald {
        border: 1.5px solid rgba(16, 185, 129, 0.4);
        box-shadow: 0 6px 20px -5px rgba(16, 185, 129, 0.25);
    }
    .spec-card.emerald .spec-icon { background: rgba(16, 185, 129, 0.15); color: #34d399; }

    .spec-card.indigo {
        border: 1.5px solid rgba(99, 102, 241, 0.4);
        box-shadow: 0 6px 20px -5px rgba(99, 102, 241, 0.25);
    }
    .spec-card.indigo .spec-icon { background: rgba(99, 102, 241, 0.15); color: #818cf8; }

    .spec-card.sky {
        border: 1.5px solid rgba(14, 165, 233, 0.4);
        box-shadow: 0 6px 20px -5px rgba(14, 165, 233, 0.25);
    }
    .spec-card.sky .spec-icon { background: rgba(14, 165, 233, 0.15); color: #38bdf8; }

    .spec-icon {
        width: 36px;
        height: 36px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 8px auto;
        font-size: 1.1rem;
    }
    .spec-label {
        font-size: 0.72rem;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        font-weight: 700;
    }
    .spec-value {
        font-size: 1.1rem;
        font-weight: 800;
        color: #f8fafc;
        margin-top: 4px;
        word-break: break-word;
    }

    /* Market Insight Callout Cards */
    .insight-card {
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.8) 0%, rgba(30, 41, 59, 0.8) 100%);
        border-radius: 16px;
        padding: 18px 22px;
        border: 1px solid rgba(99, 102, 241, 0.3);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.35);
        display: flex;
        align-items: flex-start;
        gap: 14px;
        margin-top: 10px;
    }
    .insight-icon-box {
        font-size: 1.6rem;
        background: rgba(99, 102, 241, 0.2);
        padding: 10px;
        border-radius: 12px;
        border: 1px solid rgba(99, 102, 241, 0.4);
    }
    .insight-body {
        flex: 1;
    }
    .insight-title {
        font-size: 0.85rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.7px;
        color: #38bdf8;
        margin-bottom: 4px;
    }
    .insight-desc {
        font-size: 0.95rem;
        color: #e2e8f0;
        line-height: 1.4;
    }

    /* Modern Tabs Styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 10px;
        background: rgba(15, 23, 42, 0.6);
        padding: 6px 8px;
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 22px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 12px;
        padding: 10px 22px;
        background-color: transparent;
        border: none;
        color: #94a3b8;
        font-weight: 600;
        font-size: 0.95rem;
        transition: all 0.25s ease;
    }
    .stTabs [data-baseweb="tab"]:hover {
        color: #f8fafc;
        background-color: rgba(255, 255, 255, 0.04);
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.35) 0%, rgba(217, 70, 239, 0.3) 100%) !important;
        border: 1px solid rgba(139, 92, 246, 0.6) !important;
        color: #ffffff !important;
        box-shadow: 0 4px 20px rgba(99, 102, 241, 0.35) !important;
    }

    /* Buttons: Ultra-vivid gradients */
    .stButton > button {
        background: linear-gradient(135deg, #06b6d4 0%, #6366f1 50%, #d946ef 100%) !important;
        color: #ffffff !important;
        font-weight: 700 !important;
        border-radius: 14px !important;
        border: none !important;
        padding: 13px 28px !important;
        font-size: 1.05rem !important;
        letter-spacing: 0.3px !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 6px 25px rgba(99, 102, 241, 0.45) !important;
        width: 100% !important;
    }
    .stButton > button:hover {
        transform: translateY(-2px) scale(1.01) !important;
        box-shadow: 0 10px 35px rgba(217, 70, 239, 0.6) !important;
        filter: brightness(1.08) !important;
    }
    .stButton > button:active {
        transform: translateY(0) scale(0.99) !important;
    }

    /* Download Buttons */
    .stDownloadButton > button {
        background: linear-gradient(135deg, #059669 0%, #10b981 100%) !important;
        color: #ffffff !important;
        font-weight: 700 !important;
        border-radius: 12px !important;
        border: none !important;
        padding: 10px 22px !important;
        box-shadow: 0 4px 18px rgba(16, 185, 129, 0.35) !important;
        transition: all 0.3s ease !important;
    }
    .stDownloadButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(16, 185, 129, 0.5) !important;
        filter: brightness(1.1) !important;
    }

    /* Comparison Cards (Tab 2) */
    .compare-card-a {
        background: linear-gradient(135deg, rgba(6, 182, 212, 0.12) 0%, rgba(15, 23, 42, 0.85) 100%);
        border: 1.5px solid rgba(6, 182, 212, 0.45);
        border-radius: 20px;
        padding: 22px;
        text-align: center;
        box-shadow: 0 8px 30px rgba(6, 182, 212, 0.2);
    }
    .compare-card-b {
        background: linear-gradient(135deg, rgba(217, 70, 239, 0.12) 0%, rgba(15, 23, 42, 0.85) 100%);
        border: 1.5px solid rgba(217, 70, 239, 0.45);
        border-radius: 20px;
        padding: 22px;
        text-align: center;
        box-shadow: 0 8px 30px rgba(217, 70, 239, 0.2);
    }

    .diff-banner {
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(16, 185, 129, 0.2) 100%);
        border: 1.5px solid rgba(99, 102, 241, 0.4);
        border-radius: 16px;
        padding: 16px 20px;
        text-align: center;
        font-size: 1.15rem;
        font-weight: 600;
        margin: 20px 0;
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.3);
    }

    /* Leaderboard Cards (Tab 3) */
    .leaderboard-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 24px;
    }
    @media (max-width: 768px) {
        .leaderboard-grid {
            grid-template-columns: 1fr;
        }
    }

    .rank-card {
        border-radius: 18px;
        padding: 22px 18px;
        text-align: center;
        position: relative;
        backdrop-filter: blur(14px);
    }
    .rank-card.gold {
        background: linear-gradient(135deg, rgba(245, 158, 11, 0.15) 0%, rgba(15, 23, 42, 0.9) 100%);
        border: 2px solid rgba(245, 158, 11, 0.6);
        box-shadow: 0 8px 35px rgba(245, 158, 11, 0.25);
    }
    .rank-card.silver {
        background: linear-gradient(135deg, rgba(6, 182, 212, 0.12) 0%, rgba(15, 23, 42, 0.9) 100%);
        border: 1.5px solid rgba(6, 182, 212, 0.45);
        box-shadow: 0 8px 30px rgba(6, 182, 212, 0.18);
    }
    .rank-card.bronze {
        background: linear-gradient(135deg, rgba(249, 115, 22, 0.12) 0%, rgba(15, 23, 42, 0.9) 100%);
        border: 1.5px solid rgba(249, 115, 22, 0.4);
        box-shadow: 0 8px 30px rgba(249, 115, 22, 0.15);
    }

    /* Inputs, selectboxes, and sliders */
    .stSelectbox div[data-baseweb="select"] > div {
        background-color: rgba(15, 23, 42, 0.8) !important;
        border: 1px solid rgba(99, 102, 241, 0.3) !important;
        border-radius: 12px !important;
        color: #f8fafc !important;
    }
    .stNumberInput div[data-baseweb="input"] {
        background-color: rgba(15, 23, 42, 0.8) !important;
        border: 1px solid rgba(99, 102, 241, 0.3) !important;
        border-radius: 12px !important;
        color: #f8fafc !important;
    }
    .stSlider [data-baseweb="slider"] {
        padding-top: 12px;
    }

    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    ::-webkit-scrollbar-track {
        background: #070a13;
    }
    ::-webkit-scrollbar-thumb {
        background: #312e81;
        border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: #4f46e5;
    }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------
# Load Artifacts and Model
# ---------------------------------------------------------
MODEL_FILE = "best_model.joblib"
METRICS_FILE = "model_metrics.json"
METADATA_FILE = "model_metadata.json"
DATA_FILE = "car_data_clean.csv"

@st.cache_resource
def load_model_and_metadata():
    if not os.path.exists(MODEL_FILE) or not os.path.exists(METRICS_FILE) or not os.path.exists(METADATA_FILE):
        return None, None, None, None
    
    pipeline = joblib.load(MODEL_FILE)
    with open(METRICS_FILE, "r") as f:
        metrics_data = json.load(f)
    with open(METADATA_FILE, "r") as f:
        metadata = json.load(f)
    
    clean_df = None
    if os.path.exists(DATA_FILE):
        clean_df = pd.read_csv(DATA_FILE)
        
    return pipeline, metrics_data, metadata, clean_df

model_pipeline, metrics_data, metadata, clean_df = load_model_and_metadata()

# Check if model exists; if not, show setup prompt
if model_pipeline is None:
    st.error("⚠️ Trained model artifacts not found! Please run `train.py` first to train the models.")
    if st.button("🚀 Train Models Now"):
        with st.spinner("Training machine learning models (Linear Regression, Random Forest, XGBoost)..."):
            import train
            raw = train.download_data()
            clean = train.clean_data(raw)
            train.train_and_evaluate(clean)
            st.success("Training completed! Please refresh this page.")
            st.rerun()
    st.stop()

# Helper function to format currency
def format_currency(val):
    return f"₹ {val:,.0f}"

# ---------------------------------------------------------
# Sidebar Inputs with Vibrant Section Badges
# ---------------------------------------------------------
st.sidebar.markdown("""
<div style="text-align: center; padding: 12px 0 16px 0;">
    <div style="font-size: 1.8rem; font-weight: 800; background: linear-gradient(135deg, #38bdf8 0%, #818cf8 50%, #ec4899 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
        ⚙️ Config Studio
    </div>
    <div style="color: #94a3b8; font-size: 0.85rem; font-weight: 500; margin-top: 4px;">
        Adjust vehicle specs to trigger instant ML pricing
    </div>
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown('<div class="sidebar-section-header">🏷️ Vehicle Identity</div>', unsafe_allow_html=True)
brands = metadata["brands"]
selected_brand = st.sidebar.selectbox("Brand / Make", brands, index=0)

models_for_brand = metadata["brand_model_map"].get(selected_brand, [selected_brand])
selected_model = st.sidebar.selectbox("Model Series", models_for_brand, index=0)

num_stats = metadata["num_stats"]
selected_year = st.sidebar.slider(
    "📅 Year of Manufacture",
    min_value=int(num_stats["year"]["min"]),
    max_value=int(num_stats["year"]["max"]),
    value=int(num_stats["year"]["default"]),
    step=1
)

st.sidebar.markdown('<div class="sidebar-section-header">⚡ Powertrain & Fuel</div>', unsafe_allow_html=True)
fuel_types = metadata["fuel_types"]
selected_fuel = st.sidebar.selectbox("⛽ Fuel Type", fuel_types, index=0)

transmissions = metadata["transmissions"]
selected_transmission = st.sidebar.selectbox("🕹️ Transmission", transmissions, index=0)

col_sb1, col_sb2 = st.sidebar.columns(2)
with col_sb1:
    selected_mileage = st.number_input(
        "Mileage (kmpl)",
        min_value=5.0,
        max_value=45.0,
        value=float(num_stats["mileage"]["default"]),
        step=0.5
    )
with col_sb2:
    selected_engine = st.number_input(
        "Engine (CC)",
        min_value=500.0,
        max_value=6000.0,
        value=float(num_stats["engine"]["default"]),
        step=50.0
    )

st.sidebar.markdown('<div class="sidebar-section-header">🛣️ Odometer & Power</div>', unsafe_allow_html=True)
selected_km = st.sidebar.number_input(
    "Kilometers Driven",
    min_value=100,
    max_value=600000,
    value=int(num_stats["km_driven"]["default"]),
    step=1000
)

selected_power = st.sidebar.number_input(
    "Max Power (bhp)",
    min_value=30.0,
    max_value=600.0,
    value=float(num_stats["max_power"]["default"]),
    step=5.0
)

predict_btn = st.sidebar.button("🔮 Calculate Valuation", use_container_width=True)

# ---------------------------------------------------------
# Hero Header & Live KPI Stat Bar
# ---------------------------------------------------------
st.markdown("""
<div style="text-align: center; margin-bottom: 20px; padding: 10px 0;">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(99, 102, 241, 0.18); border: 1px solid rgba(99, 102, 241, 0.4); padding: 6px 18px; border-radius: 30px; font-size: 0.85rem; font-weight: 700; color: #a5b4fc; margin-bottom: 12px;">
        <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #22d3ee; box-shadow: 0 0 10px #22d3ee;"></span>
        NEXT-GEN AUTOMOTIVE AI PRICING SUITE
    </div>
    <h1 style="font-size: 3.2rem; font-weight: 900; margin: 0; line-height: 1.15; background: linear-gradient(135deg, #ffffff 0%, #67e8f9 30%, #818cf8 65%, #f472b6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; filter: drop-shadow(0 4px 20px rgba(99,102,241,0.3));">
        AutoPrice AI Studio
    </h1>
    <p style="color: #94a3b8; font-size: 1.15rem; max-width: 720px; margin: 10px auto 0 auto; font-weight: 500;">
        Real-time market valuation powered by Random Forest & XGBoost ensemble models trained on comprehensive automotive sales data.
    </p>
</div>
""", unsafe_allow_html=True)

# Top Live KPI Bar
best_r2_val = metrics_data.get("best_r2", 0.8704)
st.markdown(f"""
<div class="kpi-row">
    <div class="kpi-item">
        <span class="kpi-icon">🎯</span>
        <div>
            <div class="kpi-title">Accuracy (R² Score)</div>
            <div class="kpi-val" style="color: #34d399;">{best_r2_val:.4f} (87.0%)</div>
        </div>
    </div>
    <div class="kpi-item">
        <span class="kpi-icon">⚡</span>
        <div>
            <div class="kpi-title">Inference Latency</div>
            <div class="kpi-val" style="color: #38bdf8;">&lt; 5 ms</div>
        </div>
    </div>
    <div class="kpi-item">
        <span class="kpi-icon">🚘</span>
        <div>
            <div class="kpi-title">Verified Records</div>
            <div class="kpi-val" style="color: #fbbf24;">6,898 Cars</div>
        </div>
    </div>
    <div class="kpi-item">
        <span class="kpi-icon">🏆</span>
        <div>
            <div class="kpi-title">Champion Model</div>
            <div class="kpi-val" style="color: #f472b6;">{metrics_data.get('best_model', 'Random Forest')}</div>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# ---------------------------------------------------------
# Navigation Tabs
# ---------------------------------------------------------
tab1, tab2, tab3, tab4 = st.tabs([
    "🎯 Real-Time Valuation",
    "⚖️ Head-to-Head Comparison",
    "📊 Model Analytics & Charts",
    "📁 Bulk CSV Predictor"
])

# ---------------------------------------------------------
# Tab 1: Single Prediction
# ---------------------------------------------------------
with tab1:
    input_data = pd.DataFrame([{
        "brand": selected_brand,
        "model": selected_model,
        "year": selected_year,
        "km_driven": selected_km,
        "fuel": selected_fuel,
        "transmission": selected_transmission,
        "mileage": selected_mileage,
        "engine": selected_engine,
        "max_power": selected_power
    }])

    # Compute prediction
    predicted_val = float(model_pipeline.predict(input_data)[0])
    predicted_val = max(15000.0, predicted_val) # non-negative safeguard

    lower_bound = predicted_val * 0.93
    upper_bound = predicted_val * 1.07

    # Prediction Hero Card with rich colors and visual meter
    st.markdown(f"""
    <div class="prediction-hero-card">
        <div class="hero-badge">
            <span class="pulse-dot"></span>
            ACTIVE PIPELINE: {metrics_data['best_model'].upper()} • TEST R² {metrics_data['best_r2']}
        </div>
        <div style="color: #cbd5e1; font-size: 1.15rem; font-weight: 600; letter-spacing: 1px; text-transform: uppercase;">
            Estimated Fair Market Value
        </div>
        <div class="price-tag-vivid">{format_currency(predicted_val)}</div>
        <div class="price-range-container">
            <div class="range-chip low">
                <span>🔻 Quick-Sale / Trade-in:</span>
                <strong>{format_currency(lower_bound)}</strong>
            </div>
            <div class="range-chip fair">
                <span>⭐ Fair Market Sweet Spot:</span>
                <strong>{format_currency(predicted_val)}</strong>
            </div>
            <div class="range-chip high">
                <span>🔺 Certified Dealer Ask:</span>
                <strong>{format_currency(upper_bound)}</strong>
            </div>
        </div>
        <div class="valuation-meter-bar"></div>
        <div class="meter-labels">
            <span>Budget / High KM</span>
            <span>Median Market</span>
            <span>Premium Showroom</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Color-Coded Specification Grid
    st.markdown("""
    <div style="display: flex; align-items: center; gap: 8px; margin: 16px 0 14px 0;">
        <span style="font-size: 1.3rem;">📋</span>
        <h3 style="margin: 0; font-size: 1.3rem; font-weight: 800; color: #f8fafc;">
            Active Vehicle Profile Summary
        </h3>
    </div>
    """, unsafe_allow_html=True)

    sc1, sc2, sc3, sc4, sc5, sc6 = st.columns(6)
    with sc1:
        st.markdown(f"""
        <div class="spec-card cyan">
            <div class="spec-icon">🚘</div>
            <div class="spec-label">Make & Model</div>
            <div class="spec-value" style="color: #22d3ee;">{selected_brand}<br><span style="font-size: 0.95rem; font-weight: 600; color: #e2e8f0;">{selected_model}</span></div>
        </div>
        """, unsafe_allow_html=True)
    with sc2:
        st.markdown(f"""
        <div class="spec-card amber">
            <div class="spec-icon">📅</div>
            <div class="spec-label">Model Year</div>
            <div class="spec-value" style="color: #fbbf24;">{selected_year}<br><span style="font-size: 0.85rem; font-weight: 600; color: #cbd5e1;">{2024 - selected_year} Years Old</span></div>
        </div>
        """, unsafe_allow_html=True)
    with sc3:
        st.markdown(f"""
        <div class="spec-card magenta">
            <div class="spec-icon">🕹️</div>
            <div class="spec-label">Transmission</div>
            <div class="spec-value" style="color: #f472b6;">{selected_transmission}</div>
        </div>
        """, unsafe_allow_html=True)
    with sc4:
        st.markdown(f"""
        <div class="spec-card emerald">
            <div class="spec-icon">⛽</div>
            <div class="spec-label">Fuel System</div>
            <div class="spec-value" style="color: #34d399;">{selected_fuel}</div>
        </div>
        """, unsafe_allow_html=True)
    with sc5:
        st.markdown(f"""
        <div class="spec-card indigo">
            <div class="spec-icon">🔧</div>
            <div class="spec-label">Engine & Power</div>
            <div class="spec-value" style="color: #a5b4fc;">{int(selected_engine)} CC<br><span style="font-size: 0.85rem; font-weight: 600; color: #cbd5e1;">{int(selected_power)} bhp</span></div>
        </div>
        """, unsafe_allow_html=True)
    with sc6:
        st.markdown(f"""
        <div class="spec-card sky">
            <div class="spec-icon">🛣️</div>
            <div class="spec-label">Odometer & Mileage</div>
            <div class="spec-value" style="color: #38bdf8;">{selected_km:,} km<br><span style="font-size: 0.85rem; font-weight: 600; color: #cbd5e1;">{selected_mileage} kmpl</span></div>
        </div>
        """, unsafe_allow_html=True)

    # Market Intelligence Cards
    if clean_df is not None:
        brand_df = clean_df[clean_df["brand"] == selected_brand]
        if not brand_df.empty:
            avg_brand_price = brand_df["selling_price"].median()
            delta = predicted_val - avg_brand_price
            delta_pct = (delta / avg_brand_price) * 100
            sentiment = "above" if delta >= 0 else "below"
            sentiment_color = "#34d399" if delta >= 0 else "#38bdf8"
            est_depreciation = min(85, max(5, int((2024 - selected_year) * 6.5)))
            retained_value = 100 - est_depreciation

            col_insight1, col_insight2 = st.columns(2)
            with col_insight1:
                st.markdown(f"""
                <div class="insight-card">
                    <div class="insight-icon-box" style="border-color: rgba(6,182,212,0.4); background: rgba(6,182,212,0.15);">📊</div>
                    <div class="insight-body">
                        <div class="insight-title" style="color: #22d3ee;">Brand Comparative Intelligence</div>
                        <div class="insight-desc">
                            This vehicle is priced 
                            <strong style="color: {sentiment_color};">{abs(delta_pct):.1f}% {sentiment}</strong> 
                            the median market price for <strong>{selected_brand}</strong> ({format_currency(avg_brand_price)}).
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            with col_insight2:
                st.markdown(f"""
                <div class="insight-card">
                    <div class="insight-icon-box" style="border-color: rgba(245,158,11,0.4); background: rgba(245,158,11,0.15);">📉</div>
                    <div class="insight-body">
                        <div class="insight-title" style="color: #fbbf24;">Depreciation & Retained Value</div>
                        <div class="insight-desc">
                            At <strong>{2024 - selected_year} years old</strong>, typical market depreciation is ~<strong style="color: #f43f5e;">{est_depreciation}%</strong>, 
                            retaining approximately <strong style="color: #34d399;">{retained_value}%</strong> of original asset value.
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

# ---------------------------------------------------------
# Tab 2: Compare Cars Side-by-Side
# ---------------------------------------------------------
with tab2:
    st.markdown("""
    <div style="margin-bottom: 20px;">
        <h3 style="font-size: 1.6rem; font-weight: 800; background: linear-gradient(135deg, #38bdf8, #818cf8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0;">
            ⚖️ Real-Time Dual Vehicle Comparison Matrix
        </h3>
        <p style="color: #94a3b8; font-size: 0.95rem; margin-top: 4px;">
            Configure two cars side-by-side to compare valuations, power output, depreciation, and market positioning.
        </p>
    </div>
    """, unsafe_allow_html=True)

    colA, colB = st.columns(2)
    with colA:
        st.markdown("""
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
            <span style="display: inline-block; padding: 4px 12px; border-radius: 8px; background: rgba(6,182,212,0.2); color: #22d3ee; font-weight: 800; border: 1px solid rgba(6,182,212,0.4); font-size: 0.85rem;">
                🚙 VEHICLE OPTION A
            </span>
        </div>
        """, unsafe_allow_html=True)
        cA_brand = st.selectbox("Brand A", brands, index=0, key="ca_brand")
        cA_models = metadata["brand_model_map"].get(cA_brand, [cA_brand])
        cA_model = st.selectbox("Model A", cA_models, index=0, key="ca_model")
        cA_year = st.slider("Year A", int(num_stats["year"]["min"]), int(num_stats["year"]["max"]), 2020, key="ca_year")
        cA_trans = st.selectbox("Transmission A", transmissions, index=0, key="ca_trans")
        cA_fuel = st.selectbox("Fuel A", fuel_types, index=0, key="ca_fuel")
        cA_km = st.number_input("Kilometers A", 100, 500000, 45000, step=5000, key="ca_km")
        cA_engine = st.number_input("Engine CC A", 600.0, 5000.0, 1197.0, step=100.0, key="ca_eng")
        cA_power = st.number_input("Max Power bhp A", 30.0, 500.0, 82.0, step=5.0, key="ca_pow")
        cA_mileage = st.number_input("Mileage kmpl A", 5.0, 40.0, 20.0, step=0.5, key="ca_mil")

    with colB:
        st.markdown("""
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
            <span style="display: inline-block; padding: 4px 12px; border-radius: 8px; background: rgba(217,70,239,0.2); color: #f472b6; font-weight: 800; border: 1px solid rgba(217,70,239,0.4); font-size: 0.85rem;">
                🚗 VEHICLE OPTION B
            </span>
        </div>
        """, unsafe_allow_html=True)
        cB_brand = st.selectbox("Brand B", brands, index=min(1, len(brands)-1), key="cb_brand")
        cB_models = metadata["brand_model_map"].get(cB_brand, [cB_brand])
        cB_model = st.selectbox("Model B", cB_models, index=0, key="cb_model")
        cB_year = st.slider("Year B", int(num_stats["year"]["min"]), int(num_stats["year"]["max"]), 2018, key="cb_year")
        cB_trans = st.selectbox("Transmission B", transmissions, index=min(1, len(transmissions)-1), key="cb_trans")
        cB_fuel = st.selectbox("Fuel B", fuel_types, index=min(1, len(fuel_types)-1), key="cb_fuel")
        cB_km = st.number_input("Kilometers B", 100, 500000, 60000, step=5000, key="cb_km")
        cB_engine = st.number_input("Engine CC B", 600.0, 5000.0, 1498.0, step=100.0, key="cb_eng")
        cB_power = st.number_input("Max Power bhp B", 30.0, 500.0, 100.0, step=5.0, key="cb_pow")
        cB_mileage = st.number_input("Mileage kmpl B", 5.0, 40.0, 18.0, step=0.5, key="cb_mil")

    # Evaluate both
    dfA = pd.DataFrame([{
        "brand": cA_brand, "model": cA_model, "year": cA_year, "km_driven": cA_km,
        "fuel": cA_fuel, "transmission": cA_trans, "mileage": cA_mileage,
        "engine": cA_engine, "max_power": cA_power
    }])
    dfB = pd.DataFrame([{
        "brand": cB_brand, "model": cB_model, "year": cB_year, "km_driven": cB_km,
        "fuel": cB_fuel, "transmission": cB_trans, "mileage": cB_mileage,
        "engine": cB_engine, "max_power": cB_power
    }])

    priceA = max(15000.0, float(model_pipeline.predict(dfA)[0]))
    priceB = max(15000.0, float(model_pipeline.predict(dfB)[0]))
    diff = abs(priceA - priceB)
    higher_name = f"Option A ({cA_brand} {cA_model})" if priceA > priceB else f"Option B ({cB_brand} {cB_model})"
    higher_color = "#22d3ee" if priceA > priceB else "#f472b6"
    pct_diff = (diff / min(priceA, priceB)) * 100

    st.markdown("<br>", unsafe_allow_html=True)
    resA, resB = st.columns(2)
    with resA:
        st.markdown(f"""
        <div class="compare-card-a">
            <div style="color: #22d3ee; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">{cA_brand} {cA_model} ({cA_year})</div>
            <div style="font-size: 2.8rem; font-weight: 900; color: #38bdf8; text-shadow: 0 0 25px rgba(6,182,212,0.4); margin: 8px 0;">{format_currency(priceA)}</div>
            <div style="font-size: 0.85rem; color: #94a3b8;">{cA_trans} • {cA_fuel} • {int(cA_power)} bhp • {cA_km:,} km</div>
        </div>
        """, unsafe_allow_html=True)
    with resB:
        st.markdown(f"""
        <div class="compare-card-b">
            <div style="color: #f472b6; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px;">{cB_brand} {cB_model} ({cB_year})</div>
            <div style="font-size: 2.8rem; font-weight: 900; color: #ec4899; text-shadow: 0 0 25px rgba(217,70,239,0.4); margin: 8px 0;">{format_currency(priceB)}</div>
            <div style="font-size: 0.85rem; color: #94a3b8;">{cB_trans} • {cB_fuel} • {int(cB_power)} bhp • {cB_km:,} km</div>
        </div>
        """, unsafe_allow_html=True)

    # Celebratory differential banner
    st.markdown(f"""
    <div class="diff-banner">
        🏆 <strong style="color: {higher_color};">{higher_name}</strong> is valued higher by 
        <strong style="color: #f8fafc; background: rgba(255,255,255,0.1); padding: 2px 10px; border-radius: 8px;">{format_currency(diff)}</strong> 
        (<span style="color: #34d399;">+{pct_diff:.1f}%</span> valuation premium).
    </div>
    """, unsafe_allow_html=True)

    # Vibrant Comparison Bar Chart
    fig_comp = go.Figure(data=[
        go.Bar(
            name='Valuation',
            x=[f"Option A: {cA_brand} {cA_model}", f"Option B: {cB_brand} {cB_model}"],
            y=[priceA, priceB],
            marker=dict(
                color=['#06b6d4', '#d946ef'],
                line=dict(color=['#22d3ee', '#f472b6'], width=2)
            ),
            text=[format_currency(priceA), format_currency(priceB)],
            textposition='auto',
            textfont=dict(size=14, color='#ffffff', family='Plus Jakarta Sans')
        )
    ])
    fig_comp.update_layout(
        template='plotly_dark',
        title=dict(text="📊 Head-to-Head Fair Valuation Comparison", font=dict(color='#f8fafc', size=16)),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        yaxis=dict(gridcolor='rgba(255,255,255,0.08)', title="Valuation (₹)"),
        xaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
        height=360,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    st.plotly_chart(fig_comp, use_container_width=True)

# ---------------------------------------------------------
# Tab 3: Model Analytics & Visualizations
# ---------------------------------------------------------
with tab3:
    st.markdown("""
    <div style="margin-bottom: 20px;">
        <h3 style="font-size: 1.6rem; font-weight: 800; background: linear-gradient(135deg, #38bdf8, #818cf8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0;">
            📊 Model Leaderboard & Engineering Benchmarks
        </h3>
        <p style="color: #94a3b8; font-size: 0.95rem; margin-top: 4px;">
            Cross-evaluated on 20% holdout test data using strict Mean Absolute Error, RMSE, and R² performance metrics.
        </p>
    </div>
    """, unsafe_allow_html=True)

    # 3-Tier Podium Leaderboard Cards
    metrics_dict = metrics_data["metrics"]
    rf_m = metrics_dict.get("Random Forest", {})
    xgb_m = metrics_dict.get("XGBoost", {})
    lr_m = metrics_dict.get("Linear Regression", {})

    st.markdown(f"""
    <div class="leaderboard-grid">
        <div class="rank-card gold">
            <div style="font-size: 2rem;">🥇</div>
            <div style="color: #fbbf24; font-weight: 800; font-size: 1.15rem; margin-top: 4px;">Random Forest</div>
            <div style="display: inline-block; padding: 2px 10px; border-radius: 12px; background: rgba(245,158,11,0.25); color: #fbbf24; font-size: 0.75rem; font-weight: 800; margin: 6px 0;">CHAMPION PIPELINE</div>
            <div style="font-size: 1.8rem; font-weight: 900; color: #ffffff; margin-top: 6px;">R² {rf_m.get('R2', 0.8704):.4f}</div>
            <div style="font-size: 0.85rem; color: #cbd5e1; margin-top: 4px;">MAE: <strong style="color: #34d399;">₹ {rf_m.get('MAE', 78202):,.0f}</strong></div>
            <div style="font-size: 0.85rem; color: #cbd5e1;">RMSE: ₹ {rf_m.get('RMSE', 214770):,.0f}</div>
        </div>
        <div class="rank-card silver">
            <div style="font-size: 2rem;">🥈</div>
            <div style="color: #38bdf8; font-weight: 800; font-size: 1.15rem; margin-top: 4px;">XGBoost Regressor</div>
            <div style="display: inline-block; padding: 2px 10px; border-radius: 12px; background: rgba(6,182,212,0.25); color: #38bdf8; font-size: 0.75rem; font-weight: 800; margin: 6px 0;">HIGH PRECISION</div>
            <div style="font-size: 1.8rem; font-weight: 900; color: #ffffff; margin-top: 6px;">R² {xgb_m.get('R2', 0.8609):.4f}</div>
            <div style="font-size: 0.85rem; color: #cbd5e1; margin-top: 4px;">MAE: <strong style="color: #38bdf8;">₹ {xgb_m.get('MAE', 78660):,.0f}</strong></div>
            <div style="font-size: 0.85rem; color: #cbd5e1;">RMSE: ₹ {xgb_m.get('RMSE', 222497):,.0f}</div>
        </div>
        <div class="rank-card bronze">
            <div style="font-size: 2rem;">🥉</div>
            <div style="color: #fb923c; font-weight: 800; font-size: 1.15rem; margin-top: 4px;">Linear Regression</div>
            <div style="display: inline-block; padding: 2px 10px; border-radius: 12px; background: rgba(249,115,22,0.25); color: #fb923c; font-size: 0.75rem; font-weight: 800; margin: 6px 0;">LINEAR BASELINE</div>
            <div style="font-size: 1.8rem; font-weight: 900; color: #ffffff; margin-top: 6px;">R² {lr_m.get('R2', 0.7614):.4f}</div>
            <div style="font-size: 0.85rem; color: #cbd5e1; margin-top: 4px;">MAE: ₹ {lr_m.get('MAE', 115291):,.0f}</div>
            <div style="font-size: 0.85rem; color: #cbd5e1;">RMSE: ₹ {lr_m.get('RMSE', 291435):,.0f}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Feature Importance Plot with Vibrant Multi-Color Palette
    feat_imp = metrics_data.get("feature_importances", {})
    if feat_imp:
        feat_df = pd.DataFrame(list(feat_imp.items()), columns=["Feature", "Importance"])
        feat_df = feat_df.sort_values(by="Importance", ascending=True)

        fig_feat = px.bar(
            feat_df,
            x="Importance",
            y="Feature",
            orientation="h",
            color="Importance",
            color_continuous_scale=[
                [0.0, "#06b6d4"],
                [0.35, "#3b82f6"],
                [0.7, "#8b5cf6"],
                [1.0, "#ec4899"]
            ],
            title="🌟 Feature Importance Spectrum (Engine, Max Power, Year & Brand Dominance)"
        )
        fig_feat.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color='#f8fafc', family='Plus Jakarta Sans'),
            xaxis=dict(gridcolor='rgba(255,255,255,0.08)', title="Normalized Relative Weight"),
            yaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
            height=460,
            margin=dict(l=20, r=20, t=50, b=20)
        )
        st.plotly_chart(fig_feat, use_container_width=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("""
    <div style="display: flex; align-items: center; gap: 8px; margin: 10px 0 14px 0;">
        <span style="font-size: 1.3rem;">📈</span>
        <h3 style="margin: 0; font-size: 1.3rem; font-weight: 800; color: #f8fafc;">
            Exploratory Data Visualizations
        </h3>
    </div>
    """, unsafe_allow_html=True)

    if clean_df is not None:
        chart_col1, chart_col2 = st.columns(2)
        
        # Chart 1: Price vs Mileage with vibrant Fuel color coding
        with chart_col1:
            sample_chart_df = clean_df.sample(min(800, len(clean_df)), random_state=42)
            fuel_color_map = {
                "Diesel": "#06b6d4",
                "Petrol": "#ec4899",
                "CNG": "#10b981",
                "LPG": "#f59e0b"
            }
            fig_mil = px.scatter(
                sample_chart_df,
                x="mileage",
                y="selling_price",
                color="fuel",
                color_discrete_map=fuel_color_map,
                hover_data=["brand", "model", "year"],
                title="⚡ Price vs. Mileage by Fuel Type",
                labels={"mileage": "Mileage (kmpl)", "selling_price": "Price (₹)", "fuel": "Fuel Type"}
            )
            fig_mil.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color='#f8fafc', family='Plus Jakarta Sans'),
                xaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
                yaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
                height=400,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_mil, use_container_width=True)

        # Chart 2: Price vs Year with vibrant gradient box styling
        with chart_col2:
            fig_yr = px.box(
                clean_df[clean_df["year"] >= 2008],
                x="year",
                y="selling_price",
                color_discrete_sequence=["#8b5cf6"],
                title="📅 Price Distribution by Manufacture Year",
                labels={"year": "Year of Manufacture", "selling_price": "Selling Price (₹)"}
            )
            fig_yr.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color='#f8fafc', family='Plus Jakarta Sans'),
                xaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
                yaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
                height=400
            )
            st.plotly_chart(fig_yr, use_container_width=True)

        # Chart 3: Distribution of Car Selling Prices with glowing cyan bars
        fig_dist = px.histogram(
            clean_df,
            x="selling_price",
            nbins=60,
            marginal="box",
            color_discrete_sequence=["#06b6d4"],
            title="💰 Overall Selling Price Distribution Curve",
            labels={"selling_price": "Selling Price (₹)"}
        )
        fig_dist.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color='#f8fafc', family='Plus Jakarta Sans'),
            xaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
            yaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
            height=400
        )
        st.plotly_chart(fig_dist, use_container_width=True)

# ---------------------------------------------------------
# Tab 4: Batch Prediction Tool
# ---------------------------------------------------------
with tab4:
    st.markdown("""
    <div style="margin-bottom: 20px;">
        <h3 style="font-size: 1.6rem; font-weight: 800; background: linear-gradient(135deg, #38bdf8, #818cf8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0;">
            📁 High-Throughput Batch Valuation Engine
        </h3>
        <p style="color: #94a3b8; font-size: 0.95rem; margin-top: 4px;">
            Upload automotive CSV catalogs to evaluate hundreds of vehicles simultaneously with instant model inference.
        </p>
    </div>
    """, unsafe_allow_html=True)

    # Sample template download
    sample_template = pd.DataFrame([
        {
            "brand": "Maruti",
            "model": "Swift",
            "year": 2018,
            "km_driven": 45000,
            "fuel": "Petrol",
            "transmission": "Manual",
            "mileage": 21.2,
            "engine": 1197.0,
            "max_power": 82.0
        },
        {
            "brand": "Hyundai",
            "model": "Creta",
            "year": 2020,
            "km_driven": 32000,
            "fuel": "Diesel",
            "transmission": "Automatic",
            "mileage": 18.5,
            "engine": 1493.0,
            "max_power": 113.4
        },
        {
            "brand": "Honda",
            "model": "City",
            "year": 2019,
            "km_driven": 50000,
            "fuel": "Petrol",
            "transmission": "Manual",
            "mileage": 17.8,
            "engine": 1498.0,
            "max_power": 117.3
        }
    ])

    csv_template = sample_template.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Structured CSV Template",
        data=csv_template,
        file_name="sample_car_listings.csv",
        mime="text/csv"
    )

    uploaded_file = st.file_uploader("Drop your vehicle dataset (CSV) here", type=["csv"])

    if uploaded_file is not None:
        try:
            batch_df = pd.read_csv(uploaded_file)
            st.markdown("""
            <div style="font-weight: 700; color: #38bdf8; margin: 14px 0 6px 0;">
                📋 Uploaded Dataset Preview
            </div>
            """, unsafe_allow_html=True)
            st.dataframe(batch_df.head(5), use_container_width=True)

            required_cols = ["brand", "model", "year", "km_driven", "fuel", "transmission", "mileage", "engine", "max_power"]
            missing_cols = [col for col in required_cols if col not in batch_df.columns]

            if missing_cols:
                st.error(f"Missing required columns in CSV: `{', '.join(missing_cols)}`. Please use the template above.")
            else:
                if st.button("⚡ Run Bulk Valuation", key="run_bulk"):
                    with st.spinner("Generating machine learning valuations across fleet..."):
                        preds = model_pipeline.predict(batch_df[required_cols])
                        preds = [max(15000.0, round(float(p), 2)) for p in preds]
                        batch_df["Predicted_Price_INR"] = preds
                        batch_df["Predicted_Price_Formatted"] = [format_currency(p) for p in preds]
                        
                        st.success(f"🎉 Valuation successfully generated for all {len(batch_df)} vehicles!")
                        st.dataframe(batch_df, use_container_width=True)

                        result_csv = batch_df.to_csv(index=False).encode('utf-8')
                        st.download_button(
                            label="📥 Export Valued Fleet Results (CSV)",
                            data=result_csv,
                            file_name="car_fleet_valuations.csv",
                            mime="text/csv"
                        )
        except Exception as err:
            st.error(f"Error processing CSV file: {err}")

# Footer
st.markdown("""
<div style="text-align: center; margin-top: 60px; padding: 24px; color: #64748b; font-size: 0.85rem; border-top: 1px solid rgba(255,255,255,0.08);">
    <strong style="color: #a5b4fc;">AutoPrice AI Studio</strong> • Crafted with Streamlit, Scikit-Learn & XGBoost • High-Performance Machine Learning Valuation Platform
</div>
""", unsafe_allow_html=True)
